# TEAM AJA CASE STUDY 1
title: "Case Study One:  Beers and Breweries, a Data Analysis"
authors: "Alexander Sepenu, Ana Alfaro and Jake Harrison"


For Fifty Stater Package - 

1.  Please download compressed file from
https://cran.r-project.org/src/contrib/Archive/fiftystater/fiftystater_1.0.1.tar.gz

2. Go to Tools - Install Packages - Install From: Archived Package File

3. Select downloaded file from folder location

4. Click Install